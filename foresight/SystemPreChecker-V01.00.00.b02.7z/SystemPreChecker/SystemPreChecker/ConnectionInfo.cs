﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SystemPreChecker
{
    public class ConnectionInfo
    {
        public string DSN { get; set; }
        public string UID { get; set; }
        public string PWD { get; set; }
    }
}
